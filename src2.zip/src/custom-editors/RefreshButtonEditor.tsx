import React from 'react';
import { Button, useTheme } from '@grafana/ui';
import { StandardEditorProps } from '@grafana/data';

export const RefreshButton: React.FC<StandardEditorProps<boolean>> = ({ value, onChange }) => {
  const theme = useTheme();
  return (
    <Button style={getButtonStyle(theme.isDark)} onClick={() => onChange(!value)}>
      Refresh
    </Button>
  );
};

const getButtonStyle = (isDark: boolean) => {
  if (isDark) {
    return {
      background: '#141619',
      backgroundColor: '#141619',
      color: '#7b8087',
      borderColor: '#7b8087',
      padding: '8px',
    };
  } else {
    return {
      background: '#FFFFFF',
      backgroundColor: '#FFFFFF',
      color: '#7b8087',
      borderColor: '#7b8087',
      padding: '8px',
    };
  }
};
