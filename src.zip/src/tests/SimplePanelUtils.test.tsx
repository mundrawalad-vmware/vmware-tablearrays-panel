// import React from 'react';
// import {
//   getDataFrameFromQuery,
//   getDisplayComponent,
//   getDisplayDataByField,
//   getMaterialTableOptions,
// } from '../utils/SimplePanelUtils';
// import { Table } from '../components/Table';
// import { DataFrame, toDataFrame } from '@grafana/data';

// // Test data ---------------------------------------------------
// const testArrayCPU = [
//   { CPU: 21, PID: 4624, SessionId: 2 },
//   { CPU: 1, PID: 5712, SessionId: 4 },
// ];

// const testArrayMemory = [
//   { CPU: 21, PID: 4624, SessionId: 2 },
//   { CPU: 1, PID: 5712, SessionId: 4 },
// ];
// // DataFrame to mock the resulting query in Grafana
// const testDataFrame = toDataFrame({
//   name: 'dataframe',
//   fields: [
//     { name: 'topCPUConsumers', type: 'string', values: [testArrayCPU] },
//     { name: 'topMemConsumers', type: 'string', values: [testArrayMemory] },
//     { name: '@timestamp', type: 'time', values: ['2021-05-28T17:15:33.517459700+00:00'] },
//   ],
// });

// const testOptions = {
//   search: true,
//   paging: true,
//   exportButton: true,
//   headerStyle: { backgroundColor: '#fff', color: '#000' },
// };

// // Test cases ---------------------------------------------------

// /* Test cases for the getDisplayComponent function
//    Responsible for returning the appropriate component to be displayed on the main panel
//    It is given the dataframe from the query, and the users selected field to display
//    Based on the validity of the dataframe and field name, the function will return
//    a corresponding component
// */
// describe('getDisplayComponent', () => {
//   it('should return a h1 tag saying No data when given an empty dataframe', () => {
//     let emptyDataFrame: DataFrame;
//     const expectedComponent = <h1>No data</h1>;
//     const receivedDisplayComponent = getDisplayComponent(emptyDataFrame!, '', undefined);
//     expect(receivedDisplayComponent).toEqual(expectedComponent);
//   });
//   it('should return Table component containing whole DataFrame with the default option when given an undefined field', () => {
//     let undefinedField: string;
//     const receivedDisplayComponent = getDisplayComponent(testDataFrame, undefinedField!, undefined);
//     const expectedComponent = (
//       <Table data={testDataFrame} userSelectedField={'default'} options={testOptions} title={'default'} />
//     );
//     expect(receivedDisplayComponent).toEqual(expectedComponent);
//   });
//   it('should return Table component containing whole DataFrame with the default option when given an invalid field', () => {
//     const receivedDisplayComponent = getDisplayComponent(testDataFrame, 'topGPUConsumers', undefined);
//     const expectedComponent = (
//       <Table data={testDataFrame} userSelectedField={'default'} options={testOptions} title={'default'} />
//     );
//     expect(receivedDisplayComponent).toEqual(expectedComponent);
//   });
//   it('should return Table component containing whole DataFrame when data valid and query is default', () => {
//     const receivedDisplayComponent = getDisplayComponent(testDataFrame, 'default', undefined);
//     const expectedComponent = (
//       <Table data={testDataFrame} userSelectedField={'default'} options={testOptions} title={'default'} />
//     );
//     expect(receivedDisplayComponent).toEqual(expectedComponent);
//   });
//   it('should return Table component w/ matching query data when both data and query are valid for topMemConsumers', () => {
//     const expectedComponent = (
//       <Table
//         data={testArrayMemory}
//         userSelectedField={'topMemConsumers'}
//         options={testOptions}
//         title={'topMemConsumers'}
//       />
//     );
//     const receivedDisplayComponent = getDisplayComponent(testDataFrame, 'topMemConsumers', undefined);
//     expect(receivedDisplayComponent).toEqual(expectedComponent);
//   });
//   it('should return Table component w/ matching query data when both data and query are valid for topCPUConsumers', () => {
//     const expectedComponent = (
//       <Table
//         data={testArrayCPU}
//         userSelectedField={'topCPUConsumers'}
//         options={testOptions}
//         title={'topCPUConsumers'}
//       />
//     );
//     const receivedDisplayComponent = getDisplayComponent(testDataFrame, 'topCPUConsumers', undefined);
//     expect(receivedDisplayComponent).toEqual(expectedComponent);
//   });
// });

// /* Test cases for the getFieldValues function
//    Responsible for returning the values of a field when given
//    a DataFrame and a field name
// */
// describe('getDisplayDataByField', () => {
//   it('should return the passed DataFrame and defualt as userSelected field when the field was default', () => {
//     const expectedData = {
//       data: testDataFrame,
//       userSelectedField: 'default',
//     };
//     const receivedValues = getDisplayDataByField(testDataFrame, 'default');
//     expect(receivedValues).toEqual(expectedData);
//   });
//   it('should return the values of topMemConsumers as data, and topMemConsumers as userSelectedField', () => {
//     const expectedData = {
//       data: testArrayMemory,
//       userSelectedField: 'topMemConsumers',
//     };
//     const receivedValues = getDisplayDataByField(testDataFrame, 'topMemConsumers');
//     expect(receivedValues).toEqual(expectedData);
//   });
//   it('should return the values of topCPUConsumers as data, and topCPUConsumers as userSelectedField', () => {
//     const expectedData = {
//       data: testArrayCPU,
//       userSelectedField: 'topCPUConsumers',
//     };
//     const receivedValues = getDisplayDataByField(testDataFrame, 'topCPUConsumers');
//     expect(receivedValues).toEqual(expectedData);
//   });
//   it('should return the passed DataFrame and default userSelectedField when an invalid field is given', () => {
//     const expectedData = {
//       data: testDataFrame,
//       userSelectedField: 'default',
//     };
//     const receivedValues = getDisplayDataByField(testDataFrame, 'topGPUConsumers');
//     expect(receivedValues).toEqual(expectedData);
//   });
// });

// /*  Test cases for the getDataFrameFromQuery function
//     Responsible for getting a DataFrame by its refId
// */
// describe('getDataFrameFromQuery', () => {
//   const testDataFrameA = toDataFrame({
//     name: 'dataframeA',
//     refId: 'A',
//     fields: [
//       { name: 'topCPUConsumers', type: 'string', values: [testArrayCPU] },
//       { name: '@timestamp', type: 'time', values: ['2021-05-28T17:15:33.517459700+00:00'] },
//     ],
//   });
//   const testDataFrameB = toDataFrame({
//     name: 'dataframeB',
//     refId: 'B',
//     fields: [
//       { name: 'topMemConsumers', type: 'string', values: [testArrayMemory] },
//       { name: '@timestamp', type: 'time', values: ['2021-05-28T17:14:31.517459700+00:00'] },
//     ],
//   });
//   it('should return the first DataFrame by default when no query is provided', () => {
//     let undefinedQuery: string;
//     const testDataFrameArray: DataFrame[] = [testDataFrameA, testDataFrameB];
//     const receivedDataFrame = getDataFrameFromQuery(testDataFrameArray, undefinedQuery!);

//     expect(receivedDataFrame).toEqual(testDataFrameA);
//   });
//   it('should return the only DataFrame when theres only one in the list', () => {
//     let undefinedQuery: string;
//     const testDataFrameArray: DataFrame[] = [testDataFrameA];
//     const receivedDataFrame = getDataFrameFromQuery(testDataFrameArray, undefinedQuery!);

//     expect(receivedDataFrame).toEqual(testDataFrameA);
//   });
//   it('should return the DataFrame with a matching refid with valid data and query', () => {
//     const testDataFrameArray: DataFrame[] = [testDataFrameA, testDataFrameB];
//     const receivedDataFrame = getDataFrameFromQuery(testDataFrameArray, 'A');

//     expect(receivedDataFrame).toEqual(testDataFrameA);
//   });
//   it('should return the DataFrame with a matching refid with valid data and query', () => {
//     const testDataFrameArray: DataFrame[] = [testDataFrameA, testDataFrameB];
//     const receivedDataFrame = getDataFrameFromQuery(testDataFrameArray, 'B');

//     expect(receivedDataFrame).toEqual(testDataFrameB);
//   });
// });

// /*  Test cases for the getOptions function
//     Responsible for returning an object containing the key/val pairs
//     which are given to Table component, and then passed to material-table
// */
// describe('getOptions', () => {
//   it('should return an object with expected keys and vals', () => {
//     const expectedOptions = {
//       search: true,
//       paging: true,
//       exportButton: true,
//       headerStyle: { backgroundColor: '#fff', color: '#000' },
//     };
//     const receivedOptions = getMaterialTableOptions();
//     expect(receivedOptions).toEqual(expectedOptions);
//   });
// });

// Old tests commented out due to dependency issues
describe('temporary test', () => {
  it('should return true', () => {
    expect(true).toEqual(true);
  });
});
