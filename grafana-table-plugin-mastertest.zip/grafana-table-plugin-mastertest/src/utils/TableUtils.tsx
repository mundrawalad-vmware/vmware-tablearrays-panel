import { DataFrame, toDataFrame } from '@grafana/data';
import { Keyable } from '../types';
import { cloneDeep } from 'lodash';

// Get the data in the appropriate form depending on the users query
// If the user made a default query, use the getDataFrame function
// Else user queried a field, use the getData function
export const getData = (data: any, query: string, isLightMode: boolean) => {
  if (query === 'default') {
    return getDataFrameInMaterialForm(data, isLightMode);
  } else {
    return getDataInMaterialForm(data, isLightMode);
  }
};

// Using the data from users selected array returns a formatted object containing data and column to pass MaterialTable
// Deep clone tableData because material ui will modify the data it is passed
// Convert tableData to dataframe and map fields into a columns array for the Material Table component
export const getDataInMaterialForm = (data: object[], isLightMode: boolean) => {
  const clonedTableData = cloneDeep(data);
  const df = toDataFrame(clonedTableData);
  const columns = isLightMode ? getColumnsFromData(df.fields) : getColumnsFromDataDarkMode(df.fields);

  // return an object containing columns and data for the material-table
  return {
    columns: columns,
    formattedData: clonedTableData,
  };
};

// Get the data from the dataframe in the form required by material-table
// Utilized for the Default query option when user wants entire DataFrame displayed
export const getDataFrameInMaterialForm = (data: DataFrame, isLightMode: boolean) => {
  const tableData = data.fields;

  // Put each field into the dataFrameAsObject with the key being field name and value being field.value
  const dataFrameAsObject: Keyable = {};
  tableData.forEach((field) => {
    const curValue = field.values.get(0);
    if (Array.isArray(curValue)) {
      dataFrameAsObject[field.name] = '[object]';
    } else {
      dataFrameAsObject[field.name] = field.values.get(0);
    }
  });

  const formattedData = [dataFrameAsObject];
  const columns = isLightMode ? getColumnsFromData(tableData) : getColumnsFromDataDarkMode(tableData);

  // return an object containing columns and data for the material-table
  return {
    columns: columns,
    formattedData: formattedData,
  };
};

// Given an array of data, it will create an array of objects with the name of each field as title/field keys
// Will be passed to material-table which accepts it as columns
export const getColumnsFromData = (data: any[]) => {
  const columns = data.map((field) => {
    return {
      title: field.name,
      field: field.name,
    };
  });

  return columns;
};

// Same as getColumns above, however adds a dark theme to each cell and header
export const getColumnsFromDataDarkMode = (data: any[]) => {
  const columns = data.map((field) => {
    return {
      title: field.name,
      field: field.name,
      cellStyle: {
        backgroundColor: '#181818',
        color: '#FFF',
      },
    };
  });
  return columns;
};
